import java.lang.*;
import java.io.*;
import java.util.*;

public class Excecoes{
    public static class ErroDeFormatacao extends Exception{
        private static final long serialVersionUID = 1L;
        public ErroDeFormatacao(){
            super("Erro de formatação");
        }
        public static void checa_se_numero(String palavra) throws ErroDeFormatacao{
            for(int i=0;i<palavra.length();i++){
                if(!Character.isDigit(palavra.charAt(i)) && palavra.charAt(i)!='.') throw new ErroDeFormatacao();
            }
        }
        public static void checa_se_data(String palavra) throws ErroDeFormatacao{
            for(int i=0;i<palavra.length();i++){
                if(!Character.isDigit(palavra.charAt(i)) && palavra.charAt(i)!='/') throw new ErroDeFormatacao();
            }
        }
        public static void checa_se_pontos(String palavra) throws ErroDeFormatacao{
            for(int i=0;i<palavra.length();i++){
                if(!Character.isDigit(palavra.charAt(i)) && palavra.charAt(i)!=',') throw new ErroDeFormatacao();
            }
        }
    }

    public static class ErroDeCodigo extends Exception{
        private static final long serialVersionUID = 1L;

        public ErroDeCodigo(String mensagem){
            super(mensagem);
        }
        public static void checa_se_existe(Docente docente, List<Docente> docentes) throws ErroDeCodigo{
            for(Docente d:docentes){
                if(d.get_codigo().equals(docente.get_codigo())){
                    throw new ErroDeCodigo("Código repetido para docente: "+d.get_codigo()+".");
                } 
            }
        }
        public static void checa_se_existe(String veiculo, List<Veiculo> veiculos) throws ErroDeCodigo{
            for(Veiculo v:veiculos){
                if(v.get_sigla().equals(veiculo)){
                    throw new ErroDeCodigo("Código repetido para veiculo: "+v.get_sigla()+".");
                } 
            }
        }
    }

    public static class ErroDeVeiculo extends Exception{
        private static final long serialVersionUID = 1L;

        public ErroDeVeiculo(String mensagem){
            super(mensagem);
        }
        public static void checa_se_existe(String veiculo, List<Veiculo> veiculos, String publicacao) throws ErroDeVeiculo{
            int contador = 0;
            for(Veiculo v:veiculos){
                if(!veiculo.equals(v.get_sigla())) contador++;
            }
            if(contador==veiculos.size()) throw new ErroDeVeiculo("Sigla de veículo não definida usada na publicação \""+publicacao+"\": "+veiculo+".");
        }
        public static void checa_se_existe(String veiculo, List<Veiculo> veiculos, int ano) throws ErroDeVeiculo{
            int contador = 0;
            for(Veiculo v:veiculos){
                if(!veiculo.equals(v.get_sigla())) contador++;
            }
            if(contador==veiculos.size()) throw new ErroDeVeiculo("Sigla de veículo não definida usada na qualificação do ano \""+ano+"\": "+veiculo+".");
        }
    }

    public static class ErroDeDocente extends Exception{
        private static final long serialVersionUID = 1L;

        public ErroDeDocente(String mensagem){
            super(mensagem);
        }
        public static void checa_se_existe(Long docente, List<Docente> docentes, String publicacao) throws ErroDeDocente{
            int contador = 0;
            for(Docente d:docentes){
                if(!d.get_codigo().equals(docente)) contador++;
            }
            if(contador==docentes.size()){
                throw new ErroDeDocente("Código de docente não definido usado na publicação \""+publicacao+"\": "+docente+".");
            } 
        }
    }

    public static class ErroDeTipo extends Exception{
        private static final long serialVersionUID = 1L;

        public ErroDeTipo(String mensagem){
            super(mensagem);
        }
        public static void checa_se_existe(String tipo, String veiculo) throws ErroDeTipo{
            if(!tipo.equals("C") && !tipo.equals("P")) throw new ErroDeTipo("Tipo de veículo desconhecido para veículo "+veiculo+": "+tipo+".");
        }
    }

    public static class ErroDeQualis extends Exception{
        private static final long serialVersionUID = 1L;

        public ErroDeQualis(String mensagem){
            super(mensagem);
        }
        public static void checa_se_existe(String qualis, String veiculo, int ano) throws ErroDeQualis{
            String[] notas = {"A1", "A2", "B1", "B2", "B3", "B4", "B5", "C"};
            int contador = 0;
            for(String nota:notas){
                if(!qualis.equals(nota)) contador++;
            }
            if(contador == notas.length) throw new ErroDeQualis("Qualis desconhecido para qualificação do veículo "+veiculo+" no ano "+ano+": "+qualis+".");
        }
        public static void checa_se_existe(String qualis, Date inicioVigencia) throws ErroDeQualis{
            String[] notas = {"A1", "A2", "B1", "B2", "B3", "B4", "B5", "C"};
            int contador = 0;
            for(String nota:notas){
                if(!qualis.equals(nota)) contador++;
            }
            if(contador == notas.length){
                Calendar calendar = new GregorianCalendar();
                calendar.setTime(inicioVigencia);
                int dia = calendar.get(Calendar.DAY_OF_MONTH);
                int mes = calendar.get(Calendar.MONTH)+1;
                int ano = calendar.get(Calendar.YEAR);
                String data = dia+"/"+mes+"/"+ano;
                throw new ErroDeQualis("Qualis desconhecido para regras de "+data+": "+qualis+".");
            }
        }
    }
}